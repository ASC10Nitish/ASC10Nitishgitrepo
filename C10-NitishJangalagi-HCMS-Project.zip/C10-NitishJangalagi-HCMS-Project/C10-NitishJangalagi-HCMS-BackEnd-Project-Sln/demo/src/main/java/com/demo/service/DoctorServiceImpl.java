package com.demo.service;



public class DoctorServiceImpl implements DoctorService {
}
