package com.demo.service;

public interface DoctorService {
}
