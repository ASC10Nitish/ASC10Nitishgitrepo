import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-6PW6VGCJ.js";
import "./chunk-CIPMNZEF.js";
import "./chunk-NGNZAHPC.js";
import "./chunk-OI7TFWLO.js";
import "./chunk-7AO4SOAP.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-5EGFENCT.js";
import "./chunk-LBBSG2YE.js";
import "./chunk-WSXI74FV.js";
import "./chunk-NGNUV6BG.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
