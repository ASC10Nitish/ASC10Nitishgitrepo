export class Hospital {
    id:number;
    hospitalId: string;
    hospitalName: string;
    address: string;
    contactNumber: string;
    email: string;
}
