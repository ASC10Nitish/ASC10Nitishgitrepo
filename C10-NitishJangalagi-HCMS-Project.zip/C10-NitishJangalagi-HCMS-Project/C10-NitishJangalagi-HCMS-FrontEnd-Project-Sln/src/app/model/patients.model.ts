export class Patient {
    id:number;
    patientId: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    dob: Date;
    address: string;
    gender: string;
}
