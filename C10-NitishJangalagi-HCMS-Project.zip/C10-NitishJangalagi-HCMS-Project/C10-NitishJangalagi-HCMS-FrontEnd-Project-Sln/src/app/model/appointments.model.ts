export class Appointment {
    id:number;
    appointmentId: string;
    doctorName: string;
    patientName: string;
    appointmentDate: Date;
    time: string;
    reason: string;
}
