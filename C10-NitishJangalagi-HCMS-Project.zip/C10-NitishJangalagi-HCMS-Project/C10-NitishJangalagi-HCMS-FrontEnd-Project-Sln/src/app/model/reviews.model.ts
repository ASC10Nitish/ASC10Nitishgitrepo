export class Review {
    id:number;
    review_id: string;
    doctor_name: string;
    patient_name: string;
    review_text: string;
    rating: number;
    date: Date;
}
