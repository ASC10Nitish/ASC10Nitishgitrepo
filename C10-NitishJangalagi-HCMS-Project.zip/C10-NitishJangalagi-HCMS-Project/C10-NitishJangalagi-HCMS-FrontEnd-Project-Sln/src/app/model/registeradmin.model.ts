export class Register{
    id: number;
    Fullname: string;
    email: string;
    password: string;
    confirmPasswrod: string;
    }
     