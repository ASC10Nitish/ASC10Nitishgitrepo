export class Doctor {
    id:number;
    doctorId: string;  
    name: string;          
    speciality: string;  
    experience: number; 
    email: string;      
    contactNumber:string;
}
