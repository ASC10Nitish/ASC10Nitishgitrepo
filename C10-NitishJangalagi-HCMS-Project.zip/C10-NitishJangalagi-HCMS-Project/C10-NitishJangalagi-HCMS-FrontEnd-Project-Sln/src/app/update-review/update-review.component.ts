import { Component } from '@angular/core';

@Component({
  selector: 'app-update-review',
  // standalone: true,
  // imports: [],
  templateUrl: './update-review.component.html',
  styleUrl: './update-review.component.css'
})
export class UpdateReviewComponent {

}
